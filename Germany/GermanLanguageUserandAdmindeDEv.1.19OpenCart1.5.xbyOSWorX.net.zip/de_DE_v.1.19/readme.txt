$Id: readme.txt 3669 2014-06-19 09:19:13Z mic $

readme German Translation (de_DE) for OpenCart
==============================================

Package/Paket	Languages (admin/user) - Sprachen (Admin/Benutzer)
Requirement		OpenCart 1.5.x
Copyright		http://osworx.net
License			GNU/GPL http://www.gnu.org/copyleft/gpl.html
-----------------------------------------------------------------

English
=======

Description
***********
Complete German Translation for admin (Backend) and user (Frontend / shop)

Installation
************

********************************************************************************
* NOTE: if the installer from OSWorX is used, instructions below are obsolete! *
********************************************************************************

To install this language package, extract the zipped package locally
and transfer the files (same structure as you can see) with FTP
to your server (current shop installation).
After that, open your OpenCart backend and follow these steps:

1. navigate to System -> Localisation -> Languages
2. Click the Edit button
3. Fill in the following values:

	3.1 Language	Deutsch (German)
	3.2 Code		de
	3.3 Locale		de_DE.UTF-8,de_DE,de-de,german
	3.4 Image		de.png
	3.5 Directory	de_DE
	3.6 Filename	de_DE
	3.7 Status		Enabled
	3.8 Sort Order	1

    Save

4. Navigate to System -> Settings
5. Click on the tab Locale and define your standard languages for
    front- and backend (backend language will not change BEFORE this step!)
6. Save
7. Ready

Deutsch
=======

Beschreibung
************
Komplette deutsche Übersetzung für Admin (Backend) und Benutzer (Frontend / Shop)

Installation
************

*******************************************************************************************
* HINWEIS: wird der Installer von OSWorX verwendet, erfolgt die Installation automatisch! *
* Nachstehende Anweisungen sind dann nicht mehr relevant und brauchen nicht durchgeführt  *
* werden!                                                                                 *
*******************************************************************************************

Um dieses Sprachenpaket zu installieren, das gezippte Paket Lokal entpacken.
Anschließend die Dateien (gleiche Verzeichnisstruktur wie sichtbar
im Ordner upload) per FTP auf den Server (Shopinstallation) kopieren.

Hinweis: das System zeigt noch die englische Sprache an, daher sind im Folgenden
etliche Begriffe in Englisch (wie im Shop angezeigt) angegeben:

1.	Backend aufrufen -> System -> Localisation -> Languages
2.	Button "Insert" anklicken
3.	Folgende Werte eingeben:

	3.1 Language	Deutsch (German)
	3.2 Code		de
	3.3 Locale		de_DE.UTF-8,de_DE,de-de,german
	3.4 Image		de.png
	3.5 Directory	de_DE
	3.6 Filename	de_DE
	3.7 Status		Enabled
	3.8 Sort Order	1

    Sichern (Button Save rechts oben anklicken)

4.	System -> Settings aufrufen
5.	Reiter "Locale" anklicken und die Standardsprache für Admin und Benutzer
	festlegen > erst dann schaltet das Backend auf die hier eingestellte Sprache
    um!
6.	Speichern (Button Save rechts oben anklicken)
7.	Fertig

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! WICHTIG !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! Um den verschiedenen Gesetzen zu entprechen (speziell EU-Raum, AT, DE),         !
! kann es erforderlich sein, dass verschiedene Variablen (z.B. $_['text_price'] ) !
! angepasst werden müssen!                                                        !
! Näheres dazu auf http://osworx.net wo wir ein spezielles Paket zur Verfügung    !
! stellen, mit welchem die rechtlichen Anforderungen abgedeckt werden.            !
!                                                                                 !
! Siehe dazu Module LEGAL sowie EUCookie auf http://osworx.net                    !
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! WICHTIG !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Support
*******
http://osworx.net/forums

Guarantee & Warranty
********************
This extension is created under best effort.
Unlikely we cannot guarantee for any lost of data or malfunction.

License
*******
Notes:
    > this package can be used for own works / derivates to following conditions:
    - headers:
		- must stay intact
        - you are allowed to add your own lines
        - you are NOT allowed to delete any line of the headers
    - this readme has always to be included in further packages
    - building own commercial packages with this as base is strictly forbidden!

Hinweise:
    > dieses Paket kann für eigene Werke zu folgenden Konditionen verwendet werden:
    - Kopfzeilen:
		- müssen intakt bleiben
        - es können eigene Zeilen hinzu gefügt werden
        - es dürfen KEINE Zeilen gelöscht werden
    - diese Datei (readme.txt) muss in allen zukünftigen Paketen inkludiert sein
    - eigene kommerzielle Pakete damit zu erstellen ist strikt verboten!

Versionen/Changelog (rev)
*************************
legend
* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note
-------------------------
1.19	2014.06.19	^ minor rewording
					# error_agree (checkout)
1.18	2014.04.11	^ OC 1.5.6.2 changes
					# typos
					# OpenBay files encoding
1.17	2014.02.16	# typo (success.php)
					+ new vars (marketplace)
					^ rewording (setting)
1.16	2014.01.10	# cart.php
1.15	2014.01.09	+ OC 1.5.6.1 vars
1.14	2013.12.02	# encoding
1.13	2013.11.28	+ closing php.tag
					^ some rewording
1.12    2013.09.08  # encoding
                    + .xml
                    + more headers
1.11    2013.08.11  + OpenCart 1.5.6 vars
                    + headers
                    + missing icon for VoicePay
1.10    2013.06.13  ^ minor rewording
1.9     2013.05.20  ^ some rewording
1.8     2013.05.20  ^ several vars rewritten
1.7     2013.05.03  # typos
1.6     2013.03.16  + missing vars (thx esprit & MrDeeTop)
                    + help to some items
                    ^ minor rewording
1.5     2013.03.05  ^ some rewording
                    + missing value (account) - thx to Patrick!
1.4     2012.11.25  # typos
1.3     2012.11.06  # typos
                    + colored items at overviews (admin)
1.2     2012.10.15  # link to contact at checkout (success) if guest
                    # typos
1.1     2012.08.28  + forgotten var (checkout/success)
1.0     2012.08.24  initial release