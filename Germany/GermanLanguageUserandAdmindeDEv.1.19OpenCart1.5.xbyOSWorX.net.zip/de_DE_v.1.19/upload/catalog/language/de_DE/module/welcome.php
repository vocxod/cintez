<?php
/**
 * @version		$Id: welcome.php 3535 2014-01-09 10:26:02Z mic $
 * @package		Translation - Frontend
 * @author		mic - http://osworx.net
 * @copyright	2013 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['heading_title']	= 'Willkommen bei %s';
?>