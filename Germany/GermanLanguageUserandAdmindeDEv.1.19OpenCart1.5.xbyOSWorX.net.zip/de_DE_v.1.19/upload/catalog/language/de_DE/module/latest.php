<?php
/**
 * @version		$Id: latest.php 3535 2014-01-09 10:26:02Z mic $
 * @package		Translation - Frontend
 * @author		mic - http://osworx.net
 * @copyright	2013 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']	= 'Neuigkeiten';
// Text
$_['text_reviews']	= '%s Beurteilungen';
?>