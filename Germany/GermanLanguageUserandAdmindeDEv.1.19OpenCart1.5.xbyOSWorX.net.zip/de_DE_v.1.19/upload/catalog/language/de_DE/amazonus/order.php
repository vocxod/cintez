<?php
/**
 * @version		$Id: order.php 3488 2013-11-28 13:46:37Z mic $
 * @package		Translation Frontend
 * @author		mic - http://osworx.net
 * @copyright	2013 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['paid_on_amazonus_text'] = 'Bezahlt über Amazon US';
$_['shipping_text']         = 'Versand';
$_['shipping_tax_text']     = 'Steuer Versand';
$_['gift_wrap_text']        = 'Geschenk';
$_['gift_wrap_tax_text']    = 'Steuer Geschenk';
$_['sub_total_text']        = 'Zwischensumme';
$_['tax_text']              = 'Steuern';
$_['total_text']            = 'Gesamt';
?>