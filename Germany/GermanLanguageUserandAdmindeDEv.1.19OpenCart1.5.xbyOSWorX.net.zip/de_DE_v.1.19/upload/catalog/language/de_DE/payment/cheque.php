<?php
/**
 * @version		$Id: cheque.php 3488 2013-11-28 13:46:37Z mic $
 * @package		Translation - Frontend
 * @author		mic - http://osworx.net
 * @copyright	2013 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_title']       = 'Scheck';
$_['text_instruction'] = 'Bezahlung per Scheck';
$_['text_payable']     = 'Zahlbar an ';
$_['text_address']     = 'Sende an';
$_['text_payment']     = 'Die Bestellung wird nach erfolgtem Zahlungseingang versendet.';
?>