<?php
/**
 * @version		$Id: order.php 3488 2013-11-28 13:46:37Z mic $
 * @package		Translation Frontend
 * @author		mic - http://osworx.net
 * @copyright	2013 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['lang_shipping']     = 'Versand';
$_['lang_discount']     = 'Rabatt';
$_['lang_tax']          = 'Steuer';
$_['lang_subtotal']     = 'Zwischensumme';
$_['lang_total']        = 'Gesamt';
?>