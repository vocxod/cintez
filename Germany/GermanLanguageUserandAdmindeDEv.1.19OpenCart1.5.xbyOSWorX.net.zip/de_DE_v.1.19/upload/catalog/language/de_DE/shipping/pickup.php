<?php
/**
 * @version		$Id: pickup.php 3496 2013-12-02 11:04:13Z mic $
 * @package		Translation Frontend
 * @author		mic - http://osworx.net
 * @copyright	2013 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_title']       = 'Abholung';
$_['text_description'] = 'Abholung von Geschäft';
?>