<?php
/**
 * @version		$Id: transaction.php 3583 2014-04-11 11:27:28Z mic $
 * @package		Translation Deutsch Frontend
 * @author		mic - http://osworx.net
 * @copyright	2013 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']			= 'Meine Transaktionen';

// Column
$_['column_date_added']		= 'Erstellt';
$_['column_description']	= 'Beschreibung';
$_['column_amount']			= 'Betrag (%s)';

// Text
$_['text_account']			= 'Konto';
$_['text_transaction']		= 'Transaktionen';
$_['text_balance']			= 'Aktueller Saldo';
$_['text_empty']			= 'Noch keine Transaktionen vorhanden.';
?>