<?php
/**
 * @version		$Id: maintenance.php 3535 2014-01-09 10:26:02Z mic $
 * @package		Translation Deutsch
 * @author		mic - http://osworx.net
 * @copyright	2013 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']		= 'Wartung';

// Text
$_['text_maintenance']	= 'Wartung';
$_['text_message']		= '<h2 style="text-align:center; color:#656565; text-transform:none; margin:30px;">Um das Shoppingerlebnis zu verbessern werden die Seiten aktuell überarbeitet</h2><br/><h3>Wir sind in Kürze wieder Online - vielen Dank.</h3>';
?>