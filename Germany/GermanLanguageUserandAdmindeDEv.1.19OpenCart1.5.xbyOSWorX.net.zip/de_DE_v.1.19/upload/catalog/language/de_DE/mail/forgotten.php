<?php
/**
 * @version		$Id: forgotten.php 3535 2014-01-09 10:26:02Z mic $
 * @package		Translation Deutsch
 * @author		mic - http://osworx.net
 * @copyright	2013 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_subject']	= '%s - Neues Passwort';
$_['text_greeting']	= 'Von %s wurde ein neues Passwort angefordert.';
$_['text_password']	= 'Das neue Passwort lautet:';
?>