<?php
/**
 * @version		$Id: not_found.php 3583 2014-04-11 11:27:28Z mic $
 * @package		Translation Deutsch
 * @author		mic - http://osworx.net
 * @copyright	2013 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']	= 'Seite nicht gefunden';

// Text
$_['text_error']	= 'Wir bedauern, aber die angeforderte Seite ist leider nicht vorhanden.<br />Sollte das Problem weiterhin bestehen bitte uns zu kontaktieren - vielen Dank.';
?>