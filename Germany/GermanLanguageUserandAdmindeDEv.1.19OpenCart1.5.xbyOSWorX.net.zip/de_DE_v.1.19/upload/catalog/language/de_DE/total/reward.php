<?php
/**
 * @version		$Id: reward.php 3583 2014-04-11 11:27:28Z mic $
 * @package		Translation Frontend
 * @author		mic - http://osworx.net
 * @copyright	2013 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_reward']   = 'Bonuspunkte (%s)';
$_['text_order_id'] = 'Bestellnr.: %s';
?>