<?php
/**
 * @version		$Id: credit.php 3583 2014-04-11 11:27:28Z mic $
 * @package		Translation Frontend
 * @author		mic - http://osworx.net
 * @copyright	2013 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['text_credit']   = 'Guthaben';
$_['text_order_id'] = 'Bestellnummer %s';
?>