<?php
/**
 * @version		$Id: footer.php 3488 2013-11-28 13:46:37Z mic $
 * @package		Translation German
 * @author		mic - http://osworx.net
 * @copyright	2013 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_footer'] = '<a onclick="window.open(\'http://www.opencart.com\');" title="OpenCart">OpenCart</a> / Dt. Übersetzung von <a onclick="window.open(\'http://osworx.net\');" title="OSWorX">OSWorX</a><br />&copy; 2009-' . date('Y') . ' Alle Rechte vorbehalten.<br />Version %s';
?>