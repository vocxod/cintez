<?php
/**
 * @version		$Id: openbaypro.php 3583 2014-04-11 11:27:28Z mic $
 * @package		Translation German
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['heading_title']		= 'OpenBay Pro';

$_['text_module']		= 'Modules';
$_['text_installed']	= 'OpenBay Pro ist jetzt installiert und verfügbar unter Erweiterungen > OpenBay Pro';
?>