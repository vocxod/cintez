<?php
/**
 * @version		$Id: error_log.php 3488 2013-11-28 13:46:37Z mic $
 * @package		Translation - Backend
 * @author		mic - http://osworx.net
 * @copyright	2013 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title'] = 'Protokolldatei';

// Text
$_['text_success']  = 'Inhalt der Protokolldatei erfolgreich gelöscht!';
?>