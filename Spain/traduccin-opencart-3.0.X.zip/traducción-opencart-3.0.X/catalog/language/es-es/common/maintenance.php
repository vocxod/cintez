<?php
// Heading
$_['heading_title']    = 'Mantenimiento';

// Text
$_['text_maintenance'] = 'Mantenimiento';
$_['text_message']     = '<h1 style="text-align:center;">Estamos realizando actualmente algunos cambios en la web. <br/>Estaremos de vuelta tan pronto como sea posible. Por favor, intentelo dentro de un momento.</h1>';