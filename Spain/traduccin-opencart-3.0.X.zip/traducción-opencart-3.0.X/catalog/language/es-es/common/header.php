<?php
// Text
$_['text_home']          = 'Inicio';
$_['text_wishlist']      = 'Lista de deseo (%s)';
$_['text_shopping_cart'] = 'Carrito de Compras';
$_['text_category']      = 'Categorias';
$_['text_account']       = 'Mi Cuenta';
$_['text_register']      = 'Registro';
$_['text_login']         = 'Iniciar Sesi&oacute;n';
$_['text_order']         = 'Historial de Pedidos';
$_['text_transaction']   = 'Transacciones';
$_['text_download']      = 'Descargas';
$_['text_logout']        = 'Salir';
$_['text_checkout']      = 'Caja';
$_['text_search']        = 'Buscar';
$_['text_all']           = 'Ver Todo';