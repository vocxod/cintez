<?php
// Heading
$_['heading_title']      = 'Mi Cuenta';

// Text
$_['text_account']       = 'Cuenta';
$_['text_my_account']    = 'Mi Cuenta';
$_['text_my_orders']     = 'Mis Compras';
$_['text_my_newsletter'] = 'Bolet&iacute;n';
$_['text_edit']          = 'Modificar Informaci&oacute;n';
$_['text_password']      = 'Cambia tu Contrase&ntilde;a';
$_['text_address']       = 'Modificar Direcci&oacute;n';
$_['text_wishlist']      = 'Modifica tu Lista de Deseos';
$_['text_order']         = 'Ver Hist&oacute;rico de Compras';
$_['text_download']      = 'Descargas';
$_['text_reward']        = 'Tus Puntos';
$_['text_return']        = 'Ver sus Peticiones de Devoluci&oacute;n';
$_['text_transaction']   = 'Tus Transacciones';
$_['text_newsletter']    = 'Subscribirse / desubscribirse del Bolet&iacute;n';
$_['text_recurring']     = 'Pagos Recurrentes';
$_['text_transactions']  = 'Transactiones';