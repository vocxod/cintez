<?php
// Heading
$_['heading_title']    = 'Seguimiento del afiliado';

// Text
$_['text_account']     = 'Cuenta';
$_['text_description'] = 'Para asegurarse de que se les paga para las remisiones que usted env&iacute;e a nosotros que tenemos que realizar un seguimiento de la derivaci&oacute;n mediante la colocaci&oacute;n de un c&oacute;digo de seguimiento en la URL\'s que une a nosotros. Usted puede utilizar las herramientas a continuaci&oacute;n para generar enlaces con el %s web.';

// Entry
$_['entry_code']       = 'C&oacute;digo de seguimiento';
$_['entry_generator']  = 'Generador de Link';
$_['entry_link']       = 'Link Seguimiento';

// Help
$_['help_generator']  = 'Escriba el nombre de un producto que usted desea ligarse a';