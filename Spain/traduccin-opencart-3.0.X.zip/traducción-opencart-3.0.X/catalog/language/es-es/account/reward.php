<?php
// Heading
$_['heading_title']      = 'Tus puntos de recompensa';

// Column
$_['column_date_added']  = 'A&ntilde;adidos el';
$_['column_description'] = 'Descripci&oacute;n';
$_['column_points']      = 'Puntos';

// Text
$_['text_account']       = 'Cuenta';
$_['text_reward']        = 'Puntos de recompensa';
$_['text_total']         = 'N&uacute;mero total de puntos es:';
$_['text_empty']         = 'Tu no tienes ning&uacute;n punto!';