<?php
// Text
$_['text_success']     = '&Eacute;xito: Su cup&oacute;n de descuento se ha aplicado!';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para acceder a la API!';
$_['error_coupon']     = 'Advertencia: Cup&oacute;n no es v&aacute;lido, vencido o que lleg&o al l&iacute;mite de uso!';