<?php
// Text
$_['text_success']     = '&Eacute;xito: Ha modificado su carrito de compras!';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para acceder a la API!';
$_['error_stock']      = 'Los productos marcados con *** no est�n disponibles en la cantidad deseada o no hay en stock!';
$_['error_minimum']    = 'Cantidad m&iacute;nima de pedido para %s es %s!';
$_['error_store']      = 'El producto no se puede comprar en la tienda que ha seleccionado!';
$_['error_required']   = '%s necesario!';