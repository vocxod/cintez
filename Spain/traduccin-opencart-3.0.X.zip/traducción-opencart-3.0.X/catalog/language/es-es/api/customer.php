<?php
// Text
$_['text_success']       = 'Usted ha modificado con &eacute;xito a los clientes';

// Error
$_['error_permission']   = 'Advertencia: Usted no tiene permiso para acceder a la API!';
$_['error_firstname']    = 'El nombre debe tener entre 1 y 32 caracteres!';
$_['error_lastname']     = 'Apellido debe tener entre 1 y 32 caracteres!';
$_['error_email']        = 'E-Mail no parece ser v&aacute;lido!';
$_['error_telephone']    = 'Tel&eacute;fono debe tener entre 3 y 32 caracteres!';
$_['error_custom_field'] = '%s necesario!';