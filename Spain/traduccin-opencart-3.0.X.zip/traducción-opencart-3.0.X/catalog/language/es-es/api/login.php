<?php
// Text
$_['text_success'] = '&Eacute;xito: sesi&eacute;n de la API ha iniciado correctamente!';

// Error
$_['error_login']  = 'Advertencia: No hay resultados para nombre de usuario y / o contrase&ntilde;a.';