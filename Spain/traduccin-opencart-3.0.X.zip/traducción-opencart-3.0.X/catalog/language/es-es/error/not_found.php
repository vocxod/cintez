<?php
// Heading
$_['heading_title'] = 'La p&aacute;gina solicitada no se encuentra!, Por favor vuelva a la principal, o utilice el men&uacute;';

// Text
$_['text_error']    = 'La p&aacute;gina solicitada no se encuentra. Por favor vuelva a la principal, o utilice el men&uacute;';