<?php
// Heading
$_['heading_title']    = 'Site Map';

// Text
$_['text_special']     = 'Ofertas Especiales';
$_['text_account']     = 'Mi Cuenta';
$_['text_edit']        = 'Informaci&oacute;n de la Cuenta';
$_['text_password']    = 'Contrase&ntilde;a';
$_['text_address']     = 'Libro de Direcciones';
$_['text_history']     = 'Hist&oacute;rico de Pedidos';
$_['text_download']    = 'Descargas';
$_['text_cart']        = 'Carrito de Compras';
$_['text_checkout']    = 'Caja';
$_['text_search']      = 'Buscar';
$_['text_information'] = 'Informaci&oacute;n';
$_['text_contact']     = 'Contacto';