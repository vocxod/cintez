<?php
// Text
$_['text_error'] = 'Informaci&oacute;n P&aacute;gina no encontrada!';