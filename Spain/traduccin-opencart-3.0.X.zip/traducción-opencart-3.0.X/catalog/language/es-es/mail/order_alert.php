<?php

// Text

$_['text_subject']      = '%s - Pedido %s';

$_['text_received']     = 'Ha recibido un Pedido.';

$_['text_order_id']     = 'Pedido ID:';

$_['text_date_added']   = 'Fecha del Pedido:';

$_['text_order_status'] = 'Estado del Pedido:';

$_['text_product']      = 'Productos';

$_['text_total']        = 'Total';

$_['text_comment']      = 'El comentario del Pedido:';
