<?php
// Text
$_['text_subject']  = '%s - Nueva Contrase&ntilde;a';
$_['text_greeting'] = 'Una nueva contrase&ntilde;a se solicit&oacute; %s.';
$_['text_password'] = 'La nueva contrase&ntilde;a es:';
