<?php
// Text
$_['text_subject']	= '%s - Comentarios de Productos';
$_['text_waiting']	= 'Revisar nuevo comentario de productos.';
$_['text_product']	= 'Producto: %s';
$_['text_reviewer']	= 'Comentario: %s';
$_['text_rating']	= 'Clasificaci&oacute;n: %s';
$_['text_review']	= 'Texto del comentario:';