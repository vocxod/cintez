<?php
// Text
$_['text_subject']  = 'Se le ha enviado un vale de regalo de %s';
$_['text_greeting'] = 'Felicitaciones, usted ha recibido un Vale de compra %s';
$_['text_from']     = 'Este certificado de regalo ha sido enviado a usted por %s';
$_['text_message']  = 'Con un mensaje que dice';
$_['text_redeem']   = 'Para canjear este certificado de regalo, anote el c&oacute;digo del vale que es <b>%s</b> a continuaci&oacute;n, haga clic en el siguiente enlace y comprar el producto que desea utilizar este vale de regalo. Puede introducir el c&oacute;digo de cup&oacute;n de regalo en la p&aacute;gina del carrito de compras antes de completar su pedido.';
$_['text_footer']   = 'Por favor, responda a este correo electr&oacute;nico si usted tiene alguna pregunta.';
