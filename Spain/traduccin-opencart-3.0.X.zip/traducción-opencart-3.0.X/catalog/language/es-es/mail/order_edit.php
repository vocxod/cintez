<?php

// Text

$_['text_subject']      = '%s - Pedido Actualizado %s';

$_['text_order_id']     = 'Pedido ID:';

$_['text_date_added']   = 'Fecha de Pedido:';

$_['text_order_status'] = 'Su Pedido ha sido actualizado al siguiente estado:';

$_['text_comment']      = 'El comentario de su pedido es:';

$_['text_link']         = 'Para ver su Pedido haga click en el enlace siguiente:';

$_['text_footer']       = 'Por favor conteste a este mail si tiene alguna pregunta.';