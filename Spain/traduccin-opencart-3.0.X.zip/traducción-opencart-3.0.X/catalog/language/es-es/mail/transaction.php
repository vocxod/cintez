<?php

// Text

$_['text_subject']  = '%s - Comisi&oacute;n del Afiliado';

$_['text_received'] = 'Felicidades! Ha recibido el pago de la comisi&oacute;n del programa de afiliados de %s';

$_['text_amount']   = 'Usted ha recibido:';

$_['text_total']    = 'Sus ingresos son:';