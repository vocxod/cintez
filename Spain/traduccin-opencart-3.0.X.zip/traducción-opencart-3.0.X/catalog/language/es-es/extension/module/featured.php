<?php
// Heading
$_['heading_title'] = 'Destacado';

// Text
$_['text_tax']      = 'Sin Iva:';