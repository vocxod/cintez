<?php
// Heading
$_['heading_title'] = 'M&aacute;s Vendido';

// Text
$_['text_tax']      = 'Sin Iva:';