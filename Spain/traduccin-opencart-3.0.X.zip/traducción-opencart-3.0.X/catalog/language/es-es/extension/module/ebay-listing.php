<?php
$_['heading_title']     = 'En nuestra tienda de eBay';