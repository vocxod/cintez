<?php
// Heading
$_['heading_title'] = 'Informaci&oacute;n';

// Text
$_['text_contact']  = 'Contacto';
$_['text_sitemap']  = 'Mapa del Sitio';