<?php
// Heading
$_['heading_title'] = 'Use vale regalo';

// Text
$_['text_success']  = '&Eacute;xito: Tu descuento del vale de regalo se ha aplicado!';

// Entry
$_['entry_voucher'] = 'Introduzca su c&oacute;digo de bono regalo aqu&iacute; ';

// Error
$_['error_voucher'] = 'Advertencia: Vale de Regalo no es v&aacute;lido o el saldo se ha agotado!';
$_['error_empty']   = 'Advertencia: Por favor, introduzca un c&oacute;digo del cup&oacute;n!';