<?php
// Heading
$_['heading_title'] = 'Use sus Puntos de Recompensa (Disponible %s)';

// Text
$_['text_success']  = 'Genial: Sus puntos de recompensa de descuento se han aplicado!';

// Entry
$_['entry_reward']  = 'Puntos a usar (Max %s)';

// Error
$_['error_reward']  = 'Advertencia: Por favor, introduzca la cantidad de puntos de recompensa para utilizar!';
$_['error_points']  = 'Advertencia: Usted no tiene %s puntos de recompensa!';
$_['error_maximum'] = 'Advertencia: El n&uacute;mero m&aacute;ximo de puntos que se puede aplicar es %s!';