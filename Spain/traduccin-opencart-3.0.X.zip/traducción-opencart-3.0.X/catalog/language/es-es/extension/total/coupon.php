<?php
// Heading
$_['heading_title'] = 'Utilice el c&oacute;digo del cup&oacute;n';

// Text
$_['text_success']  = '&Eacute;xito: Su cup&oacute;n de descuento se ha aplicado!';

// Entry
$_['entry_coupon']  = 'Introduzca su cup&oacute;n aqu&iacute;';

// Error
$_['error_coupon']  = 'Advertencia: Cup&oacute;n no es v&aacute;lido, expir&oacute; o alcanz&oacute; su l&iacute;mite de uso!';
$_['error_empty']   = 'Advertencia: Por favor, introduzca un c&oacute;digo de cup&oacute;n!';