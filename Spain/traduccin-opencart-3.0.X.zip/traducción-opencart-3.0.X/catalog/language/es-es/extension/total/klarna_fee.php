<?php
$_['text_klarna_fee'] = 'Cuota Klarna';