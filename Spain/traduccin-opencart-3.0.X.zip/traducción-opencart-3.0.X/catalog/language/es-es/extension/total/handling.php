<?php
$_['text_handling'] = 'Tasa de Tramitaci&oacute;n';