<?php
$_['text_credit']   = 'Cr&eacute;dito de la Tienda';
$_['text_order_id'] = 'Pedido ID: #%s';