<?php
// Text
$_['text_title']				= 'PayPal';
$_['text_reason']				= 'RAZ&Oacute;N';
$_['text_testmode']				= 'Advertencia: La pasarela de pago es en \'Sandbox Mode\'. Su cuenta no se cargar&aacute;.';
$_['text_total']				= 'IVA';