<?php
// Text
$_['text_paid_amazon'] 			= 'Pagar en Amazon US';
$_['text_total_shipping'] 		= 'Env&iacute;o';
$_['text_total_shipping_tax'] 	= 'Taxas de Env&iacute;o';
$_['text_total_giftwrap'] 		= 'Papel regalo';
$_['text_total_giftwrap_tax'] 	= 'taxas del papel regalo';
$_['text_total_sub'] 			= 'Sub-total';
$_['text_tax'] 					= 'Taxas';
$_['text_total'] 				= 'Total';