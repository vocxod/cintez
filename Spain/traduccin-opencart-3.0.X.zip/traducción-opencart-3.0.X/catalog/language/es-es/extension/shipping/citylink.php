<?php
// Text
$_['text_title']  = 'Ciudad de enlace';
$_['text_weight'] = 'Peso:';