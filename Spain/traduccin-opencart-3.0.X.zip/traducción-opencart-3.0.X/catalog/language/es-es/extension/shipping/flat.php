<?php
// Text
$_['text_title']       = 'Tarifa plana';
$_['text_description'] = 'Tarifa plana de env&iacute;o';