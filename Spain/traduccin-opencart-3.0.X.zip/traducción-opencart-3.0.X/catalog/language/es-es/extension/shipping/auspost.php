<?php
// Text
$_['text_title']    = 'Australia Correo';
$_['text_express']  = 'Express';
$_['text_standard'] = 'Estandar';
$_['text_eta']      = 'Dias';