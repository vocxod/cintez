<?php
// Text
$_['text_title']       = 'Entrega 48';
$_['text_description'] = 'Entrega 48';
$_['text_weight']      = 'Peso:';
$_['text_insurance']   = 'Asegurado hasta:';
$_['text_time']        = 'Tiempo Estimado: En 48 Horas';