<?php
// Text
$_['text_title']       = 'Recoger en la tienda';
$_['text_description'] = 'Recoger en la Tienda';