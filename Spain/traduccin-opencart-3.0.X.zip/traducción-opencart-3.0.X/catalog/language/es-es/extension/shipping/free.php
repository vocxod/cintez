<?php
// Text
$_['text_title']       = 'Env&iacute;o Gratuito';
$_['text_description'] = 'Env&iacute;o Gratuito';