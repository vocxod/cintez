<?php
// Text
$_['text_title']       = 'Por Art&iacute;culo';
$_['text_description'] = 'Tarifa Plana por art&iacute;culo';