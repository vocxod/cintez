<?php
// Text
$_['text_title']  = 'Env&iacute;o basado en peso';
$_['text_weight'] = 'Peso:';