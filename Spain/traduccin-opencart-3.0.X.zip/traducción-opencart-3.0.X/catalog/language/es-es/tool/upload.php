<?php
// Text
$_['text_upload']    = 'Su archivo fue subido con &eacute;xito!';

// Error
$_['error_filename'] = 'Nombre del archivo debe tener entre 3 y 64 caracteres!';
$_['error_filetype'] = 'Tipo de archivo no v&aacute;lido!';
$_['error_upload']   = 'Requiere subir archivo!';
