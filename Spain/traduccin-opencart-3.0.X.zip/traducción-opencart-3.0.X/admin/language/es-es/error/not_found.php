<?php
// Heading
$_['heading_title']  = 'P&aacute;gina No Encontrada!';

// Text
$_['text_not_found'] = 'La p&aacute;gina que est&aacute;s buscando no se pudo encontrar! P&oacute;ngase en contacto con su administrador si el problema persiste.';