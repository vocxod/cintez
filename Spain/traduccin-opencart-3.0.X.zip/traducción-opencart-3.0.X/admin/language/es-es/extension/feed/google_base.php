<?php
// Heading
$_['heading_title']    = 'Google Base';

// Text
$_['text_feed']        = 'Feeds';
$_['text_success']     = 'Genial: Usted ha moficado el feed de Google Base!';
$_['text_edit']        = 'Editar Google Base';

// Entry
$_['entry_status']     = 'Estado';
$_['entry_data_feed']  = 'Url de Feed Datos';

// Error
$_['error_permission'] = 'Atenci&oacute;n: Usted no tiene permiso para modificar el feed de Google Base!';