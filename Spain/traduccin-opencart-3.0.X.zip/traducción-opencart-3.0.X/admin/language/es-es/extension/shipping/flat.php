<?php
// Heading
$_['heading_title']    = 'Tarifa Plana';

// Text
$_['text_shipping'] = 'Env&iacute;o';
$_['text_success'] = 'Genial: Ha modificado tarifa plana de env&iacute;o!';
$_['text_edit'] = 'Editar la tarifa &uacute;nica de env&iacute;o';

// Entrada
$_['entry_cost'] = 'Coste';
$_['entry_tax_class'] = 'Clase de Impuesto';
$_['entry_geo_zone'] = 'Zona Geo';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para modificar tarifa plana de env&iacute;o';