<?php
// Heading
$_['heading_title']    = 'Recogida en Tienda';

// Text
$_['text_shipping'] = 'Env&iacute;o';
$_['text_success'] = 'Genial: Ha modificado recogida en la tienda';
$_['text_edit'] = 'Editar Recogida en la Tienda';

// Entrada
$_['entry_geo_zone'] = 'Zona Geo';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para modificar recogida en la tienda!';