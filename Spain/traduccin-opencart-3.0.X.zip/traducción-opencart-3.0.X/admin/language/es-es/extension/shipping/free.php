<?php
// Heading
$_['heading_title']    = 'Env&iacute;o Gratuito';

// Text
$_['text_shipping'] = 'Env&iacute;o Gratuito';
$_['text_success'] = 'Genial: Se ha modificado el env&iacute;o gratuito!';
$_['text_edit'] = 'Editar env&iacute;o gratuito ';

// Entrada
$_['entry_total'] = 'total';
$_['entry_geo_zone'] = 'Zona Geo';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';

// Ayuda
$_['help_total'] = 'cantidad Sub-total necesaria antes de que el m�dulo libre del env&iacute;o est&eacute; disponible.';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para modificar el env&iacute;o libre';