<?php
// Heading
$_['heading_title']     = 'Total de Pedido';

// Text
$_['text_success']      = 'Genial: Usted ha moficado el total!';
$_['text_list']         = 'Lista de Pedidos Totales';

// Column
$_['column_name']       = 'Pedidos Totales';
$_['column_status']     = 'Estado';
$_['column_sort_order'] = 'Ordenar';
$_['column_action']     = 'Acci&oacute;n';

// Error
$_['error_permission']  = 'Atenci&oacute;n: Usted no tiene permisos para modificar los totales de pedido!';