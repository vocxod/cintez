<?php
// Heading
$_['heading_title']    = 'Anti-Fraude';

// Text
$_['text_success']     = 'Genial: Ha modificado anti-fraude!';
$_['text_list']        = 'Lista Anti-Fraude';

// Column
$_['column_name']      = 'Nombre Anti-Fraud';
$_['column_status']    = 'Estado';
$_['column_action']    = 'Acci&oacute;n';

// Error
$_['error_permission'] = 'Atenci&oacute;n: Usted no tiene permisos para modificar anti-fraude!';