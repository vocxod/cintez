<?php
// Heading
$_['heading_title']    = 'Cr&eacute;dito de la Tienda';

// Text
$_['text_total'] = 'Pedios Totales';
$_['text_success'] = 'Genial: Ha modificado el total de cr&eacute;dito de la tienda';
$_['text_edit'] = 'Editar tienda de Cr&eacute;dito Total';

// Entrada
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para modificar total de cr&eacute;dito de la tienda';