<?php
// Heading
$_['heading_title']    = 'Sub-Total';

// Text
$_['text_total'] = 'Pedidos Totales';
$_['text_success'] = 'Genial: Ha modificado total de subtotal!';
$_['text_edit'] = 'Editar Sub-Total Total';

// Entrada
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para modificar total de sub-total';