<?php
// Heading
$_['heading_title']    = 'Puntos de Recompensa';

// Text
$_['text_total'] = 'Pedidos Totales';
$_['text_success'] = 'Genial: Ha modificado los puntos de recompensa totales';
$_['text_edit'] = 'Editar Total de puntos de recompensa';

// Entrada
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para modificar puntos de recompensa totales';