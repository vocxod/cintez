<?php
// Heading
$_['heading_title']    = 'Vales Regalo';

// Text
$_['text_total'] = 'Pedidos Totales';
$_['text_success'] = 'Genial: Ha modificado total del vale regalo';
$_['text_edit'] = 'Editar Total de Vales de Regalo';

// Entrada
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Pedido';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para modificar el total del vale regalo';