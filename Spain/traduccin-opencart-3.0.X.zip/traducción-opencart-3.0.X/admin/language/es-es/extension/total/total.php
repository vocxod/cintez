<?php
// Heading
$_['heading_title']    = 'Total';

// Text
$_['text_total'] = 'Pedidos Totales';
$_['text_success'] = 'Genial: Se han modificado el total de los totales!';
$_['text_edit'] = 'Editar el Total del Total';

// Entrada
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Pedido';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para modificar los totales totales';