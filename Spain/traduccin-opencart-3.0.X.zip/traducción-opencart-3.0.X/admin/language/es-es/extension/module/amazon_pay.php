<?php
// Heading
$_['heading_title'] = 'Pague con Amazon';

//Text
$_['text_module'] = 'M&oacute;dulos';
$_['text_success'] = 'Genial: Ha modificado m&oacute;dulo de pago con Amazon';
$_['text_content_top'] = 'Contenido destacado';
$_['text_content_bottom'] = 'Bottom contenido';
$_['text_column_left'] = 'columna de la izquierda';
$_['text_column_right'] = 'Columna Derecha';
$_['text_pwa_button'] = 'Pague con Amazon';
$_['text_pay_button'] = 'Pagar';
$_['text_a_button'] = 'A';
$_['text_gold_button'] = 'Oro';
$_['text_darkgray_button'] = 'gris oscuro';
$_['text_lightgray_button'] = 'gris claro';
$_['text_small_button'] = 'Peque&ntilde;o';
$_['text_medium_button'] = 'Medium';
$_['text_large_button'] = 'grande';
$_['text_x_large_button'] = 'X-Large';

// Entry
$_['entry_button_type'] = 'Tipo Button';
$_['entry_button_colour'] = 'Bot&oacute;n Color';
$_['entry_button_size'] = 'Tama&ntilde;o Button';
$_['entry_layout'] = 'dise&ntilde;o';
$_['entry_position'] = 'Posici&oacute;n';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para modificar el m&oacute;dulo de pago con Amazon';