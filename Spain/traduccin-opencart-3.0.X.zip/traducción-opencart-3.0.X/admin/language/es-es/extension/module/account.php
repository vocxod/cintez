<?php
// Heading
$_['heading_title']    = 'Cuenta';

$_['text_module'] = 'M&oacute;dulos';
$_['text_success'] = 'Genial: Ha modificado m&oacute;dulo  cuenta';
$_['text_edit'] = 'Editar M&oacute;dulo cuenta';

// Entry
$_['entry_status'] = 'Estado';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para modificar el m&oacute;dulo cuenta';