<?php
// Heading
$_['heading_title']     = 'Contenido HTML';

// Text
$_['text_module'] = 'm&oacute;dulos';
$_['text_success'] = 'Genial: Ha modificado HTML m&oacute;dulo de contenido';
$_['text_edit'] = 'Editar HTML M&oacute;dulo de contenidos';

// Entry
$_['entry_name'] = 'Nombre del m&oacute;dulo';
$_['entry_title'] = 'Heading T&iacute;tulo';
$_['entry_description'] = 'Descripci&oacute;n';
$_['entry_status'] = 'Estado';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para modificar HTML m&oacute;dulo de contenido';
$_['error_name'] = 'El Nombre del m&oacute;dulo debe estar entre 3 y 64 caracteres';