<?php
// Heading
$_['heading_title']    = 'Tienda';

// Text
$_['text_module']      = 'M&oacute;dulos';
$_['text_success']     = 'Genial: ha modificado el m&oacute;dulo tiendaa!';
$_['text_edit']        = 'Editar tiendas';

// Entry
$_['entry_admin']      = 'S&oacute;lo para Administradores';
$_['entry_status']     = 'Estado';

// Error
$_['error_permission'] = 'Atenci&oacute;n: No tiene permisos para modificar este m&oacute;dulo!';