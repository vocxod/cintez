<?php
// Heading
$_['heading_title']     = '&Uacute;timos Pedidos';

// Column
$_['column_order_id']   = 'Pedido';
$_['column_customer']   = 'Cliente';
$_['column_status']     = 'Estado';
$_['column_total']      = 'Total';
$_['column_date_added'] = 'Fecha';
$_['column_action']     = 'Aci&oacute;n';