<?php
// Text
$_['text_approve_subject'] = '% s - Su cuenta de socio ha sido activada!';
$_['text_approve_welcome'] = 'Bienvenidos y gracias por registrarse en% s!';
$_['text_approve_login'] = 'Su cuenta ha sido creada y usted puede iniciar sesi&oacute;n utilizando su direcci&oacute;n de correo electr&oacute;nico y contrase&ntilde;a, visite nuestro sitio web o en la siguiente URL:';
$_['text_approve_services'] = 'Al iniciar la sesi&oacute;n, usted ser&aacute; capaz de generar c&oacute;digos de seguimiento, los pagos de comisiones y editar la informaci&oacute;n de su cuenta.';
$_['text_approve_thanks'] = 'Gracias,';
$_['text_transaction_subject'] = '% s - Comisi&oacute;n de afiliados';
$_['text_transaction_received'] = 'Usted ha recibido comisi&oacute;n% s!';
$_['text_transaction_total'] = 'Su importe total de la comisi&oacute;n es ahora% s.';