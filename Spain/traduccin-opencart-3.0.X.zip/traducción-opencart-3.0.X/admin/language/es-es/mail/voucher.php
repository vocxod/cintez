<?php
// Text
$_['text_subject'] = 'Se le ha enviado un vale de regalo de% s';
$_['text_greeting'] = 'Felicitaciones, usted ha recibido un certificado de regalo por valor de% s';
$_['text_from'] = 'Este certificado de regalo ha sido enviado a usted por% s';
$_['text_message'] = 'Con un mensaje que dice';
$_['text_redeem'] = 'Para canjear este certificado de regalo, anote el c&oacute;digo de redenci&oacute;n que es <b>% s </ b> a continuaci&oacute;n, haga clic en el link de abajo y comprar el producto que desea utilizar este Bono regalo. Puede introducir el c&oacute;digo de cup&oacute;n de regalo en la p&aacute;gina de cesta de la compra antes de hacer clic en comprar. ';
$_['text_footer'] = 'Por favor, responda a este correo electr&oacute;nico si usted tiene alguna pregunta.';