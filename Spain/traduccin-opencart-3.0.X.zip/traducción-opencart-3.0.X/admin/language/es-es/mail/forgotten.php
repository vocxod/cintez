<?php
// Text
$_['text_subject'] = '% s - Contrase&ntilde;a reinicio solicitud';
$_['text_greeting'] = 'Se solicit&oacute; una nueva contrase&ntilde;a para la administraci&oacute;n% s.';
$_['text_change'] = 'Para restablecer su contrase&ntilde;a, haga clic en el enlace de abajo:';
$_['text_ip'] = 'La IP utilizada para hacer esta petici&oacute;n fue:% s';