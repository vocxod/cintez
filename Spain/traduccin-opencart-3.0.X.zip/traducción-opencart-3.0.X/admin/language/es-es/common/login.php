<?php
// header
$_['heading_title']  = 'Administraci&oacute;n';

// Text
$_['text_heading']   = 'Administraci&oacute;n';
$_['text_login']     = 'Por Favor introduzca sus datos de acceso.';
$_['text_forgotten'] = 'Olvid&oacute; su contrase&ntilde;a';

// Entry
$_['entry_username'] = 'Usuario';
$_['entry_password'] = 'Contrase&ntilde;a';

// Button
$_['button_login']   = 'Ingresar';

// Error
$_['error_login']    = 'No hay resultados para el nombre de usuario y / o contrase&ntilde;a.';
$_['error_token']    = 'Sesi&oacute;n no v&aacute;lida. Por favor ingresa de nuevo.';