<?php
// header
$_['heading_title']  = 'Restablecer su contrase&ntilde;a';

// Text
$_['text_reset']     = 'Restablecer su contrase&ntilde;a!';
$_['text_password']  = 'Introduce la nueva contrase&ntilde;a.';
$_['text_success']   = 'Genial: Su contrase&ntilde;a ha sido guardada.';

// Entry
$_['entry_password'] = 'Contrase&ntilde;a';
$_['entry_confirm']  = 'Confirmar';

// Error
$_['error_password'] = 'Su contrase&ntilde;a debe tener entre 5 y 20 caracteres!';
$_['error_confirm']  = 'La contrase&ntilde;a y la confirmaci&oacute;n de la contrase&ntilde;a no coinciden!';