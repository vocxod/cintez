<?php
// Heading
$_['heading_title']         		= 'Amazon США';
$_['text_openbay']					= 'OpenBay Pro';
$_['text_dashboard']				= 'Панель Amazon Америка';

// Text
$_['text_heading_settings'] 		= 'Настройки';
$_['text_heading_account'] 			= 'Сменить тарифный план';
$_['text_heading_links'] 			= 'Ссылки';
$_['text_heading_register'] 		= 'Регистрация';
$_['text_heading_bulk_listing'] 	= 'Основной список';
$_['text_heading_stock_updates'] 	= 'Обновление магазина';
$_['text_heading_saved_listings'] 	= 'Сохраненные списки';
$_['text_heading_bulk_linking'] 	= 'Основная связь';