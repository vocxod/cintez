<?php
// Heading
$_['heading_title']        				= 'Обновление магазина';
$_['text_openbay']						= 'OpenBay Pro';
$_['text_amazon']						= 'Amazon USA';

// Text
$_['text_empty']                    	= 'Нет результатов!';

// Entry
$_['entry_date_start']               	= 'Дата начала';
$_['entry_date_end']                 	= 'Дата окончания';

// Column
$_['column_ref']                      	= 'Ссылка';
$_['column_date_requested']           	= 'Требуемая дата';
$_['column_date_updated']             	= 'Дата обновления';
$_['column_status']                   	= 'Статус';
$_['column_sku']                      	= 'Артикул Amazon';
$_['column_stock']                    	= 'Наличие';