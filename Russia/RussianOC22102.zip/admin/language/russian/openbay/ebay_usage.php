<?php
// Headings
$_['heading_title']             = 'Использование';
$_['text_openbay']              = 'OpenBay Pro';
$_['text_ebay']                 = 'eBay';

// Errors
$_['error_ajax_load']      		= 'Сервер не овтечает, попробуйте позднее.';