<?php
// Heading
$_['heading_title']         		= 'Amazon EU';
$_['text_openbay']					= 'OpenBay Pro';
$_['text_dashboard']				= 'Панель управления Amazon EU';

// Text
$_['text_heading_settings'] 		= 'Установки';
$_['text_heading_account'] 			= 'Сменить тарифный план';
$_['text_heading_links'] 			= 'Ссылки на товар';
$_['text_heading_register'] 		= 'Зарегистрироваться';
$_['text_heading_bulk_listing'] 	= 'Основной список';
$_['text_heading_stock_updates'] 	= 'Обновление магазина';
$_['text_heading_saved_listings'] 	= 'Сохраненные списки';
$_['text_heading_bulk_linking'] 	= 'Основная связь';