<?php
// Heading
$_['heading_title']        				= 'Обновления наличия товаров';
$_['text_openbay']						= 'OpenBay Pro';
$_['text_amazon']						= 'Amazon EU';

// Text
$_['text_empty']                    	= 'Не выбрано!';

// Entry
$_['entry_date_start']               	= 'Дата начала';
$_['entry_date_end']                 	= 'Дата окончания';

// Column
$_['column_ref']                      	= 'Ссылка';
$_['column_date_requested']           	= 'Требуемая дата';
$_['column_date_updated']             	= 'Дата обновления';
$_['column_status']                   	= 'Статус';
$_['column_sku']                      	= 'Артикул Amazon';
$_['column_stock']                    	= 'Наличие';