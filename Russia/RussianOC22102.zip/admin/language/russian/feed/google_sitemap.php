<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text
$_['text_feed']        = 'Ленты';
$_['text_success']     = 'Лента Google Sitemap была изменена!';
$_['text_edit']        = 'Редактировать Google Sitemap';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_data_feed']  = 'URL ленты';

// Error
$_['error_permission'] = 'У Вас нет прав для изменения ленты Google Sitemap!';