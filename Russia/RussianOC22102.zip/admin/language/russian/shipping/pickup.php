<?php
// Heading
$_['heading_title']    = 'Самовывоз';

// Text
$_['text_shipping']    = 'Доставка';
$_['text_success']     = 'Изменения успешно внесены в самовывоз из магазина!';
$_['text_edit']        = 'Изменить доставку самовывоз из магазина';

// Entry
$_['entry_geo_zone']   = 'Геозоны';
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Сортировка';

// Error
$_['error_permission'] = 'У вас нет прав на изменение самовывоза из магазина!';