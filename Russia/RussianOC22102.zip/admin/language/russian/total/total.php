<?php
// Heading
$_['heading_title']    = 'Итого';

// Text
$_['text_total']       = 'Итог заказа';
$_['text_success']     = 'Вы изменили итоговую сумму!';
$_['text_edit']        = 'Редактировать итоговую сумму';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Сортировка';

// Error
$_['error_permission'] = 'У вас нет прав для изменения общей суммы!';