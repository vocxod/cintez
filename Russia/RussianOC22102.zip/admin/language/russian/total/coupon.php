<?php
// Heading
$_['heading_title']    = 'Купон';

// Text
$_['text_total']       = 'Итог заказа';
$_['text_success']     = 'Купон успешно изменен!';
$_['text_edit']        = 'Редактировать купон';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Сортировка';

// Error
$_['error_permission'] = 'У вас нет прав для изменения итога по купону!';