<?php
// Heading
$_['heading_title']    = 'Бонусные баллы';

// Text
$_['text_total']       = 'Итог заказа';
$_['text_success']     = 'Вы изменили бонусные баллы!';
$_['text_edit']        = 'Изменить бонусные баллы';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Сортировка';

// Error
$_['error_permission'] = 'У вас нет прав для изменения количества бонусных баллов!';