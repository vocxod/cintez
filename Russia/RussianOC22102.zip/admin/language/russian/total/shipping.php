<?php
// Heading
$_['heading_title']    = 'Доставка';

// Text
$_['text_total']       = 'Итог заказа';
$_['text_success']     = 'Подсчет доставки успешно изменен!';
$_['text_edit']        = 'Редактировать подсчет доставки';

// Entry
$_['entry_estimator']  = 'Расчёт доставки';
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Сортировка';

// Error
$_['error_permission'] = 'У вас нет прав для изменения подсчета доставки!';