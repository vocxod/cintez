<?php
// Heading
$_['heading_title']    = 'Подарочный сертификат';

// Text
$_['text_total']       = 'Итог заказа';
$_['text_success']     = 'Вы изменили подарочные сертификаты!';
$_['text_edit']        = 'Изменить подарочный сертификат';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Сортировка';

// Error
$_['error_permission'] = 'У вас нет прав на изменение подарочных сертификатов!';