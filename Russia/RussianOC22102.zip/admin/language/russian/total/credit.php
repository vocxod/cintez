<?php
// Heading
$_['heading_title']    = 'Кредит магазина';

// Text
$_['text_total']       = 'Итог заказа';
$_['text_success']     = 'Кредит во всем магазине изменен!';
$_['text_edit']        = 'Правка кредита во всем магазине';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Сортировка';

// Error
$_['error_permission'] = 'У вас нет прав на изменение кредита во всем магазине!';