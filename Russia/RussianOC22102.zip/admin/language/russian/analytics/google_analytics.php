<?php
$_['heading_title']    = 'Аналитика Google';

// Text
$_['text_analytics']   = 'Аналитика';
$_['text_success']	   = 'Вы успешно изменили Аналитику Google!';
$_['text_edit']        = 'Редактировать Аналитику Google';
$_['text_signup']      = 'Войдите в ваш <a href="http://www.google.com/analytics/" target="_blank"><u>Google Analytics</u></a> аккаунт и после создания профиля сайтa скопируйте и вставьте код Аналитики в это поле.';

// Entry
$_['entry_code']       = 'Код Аналитики Google';
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав на изменение Аналитики Google!';
$_['error_code']	   = 'Код обязателен!';
