<?php
// Heading
$_['heading_title']	   = 'Журнал ошибок';

// Text
$_['text_success']	   = 'Вы успешно очистили журнал ошибок!';
$_['text_list']        = 'Список ошибок';

// Error
$_['error_warning']	   = 'Внимание: ваш файл журнал ошибок %s - %s!';
$_['error_permission'] = 'У вас нет прав на очистку журнала ошибок!';