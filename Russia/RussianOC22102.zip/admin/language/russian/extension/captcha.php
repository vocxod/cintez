<?php
// Heading
$_['heading_title']    = 'Капча';

// Text
$_['text_success']     = 'Вы успешно изменили Капчу!';
$_['text_list']        = 'Список сервисов капчи';

// Column
$_['column_name']      = 'Название капчи';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав на изменение списка Капч!';
