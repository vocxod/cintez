<?php
// Heading
$_['heading_title']     = 'Итоги заказа';

// Text
$_['text_success']      = 'Итоги заказа были изменены!';
$_['text_list']         = 'Список итогов заказа';

// Column
$_['column_name']       = 'Итоговый заказ';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Сортировка';
$_['column_action']     = 'Действие';

// Error
$_['error_permission']  = 'У вас нет прав на изменение Итогов заказа!';