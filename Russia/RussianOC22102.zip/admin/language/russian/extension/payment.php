<?php
// Heading
$_['heading_title']     = 'Оплаты';

// Text
$_['text_success']      = 'Способ оплаты успешно изменен!';
$_['text_list']         = 'Список способов оплаты';

// Column
$_['column_name']       = 'Способ оплаты';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Сортировка';
$_['column_action']     = 'Действие';

// Error
$_['error_permission']  = 'У вас нет прав на изменение способов оплаты!';