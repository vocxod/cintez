<?php
// Heading
$_['heading_title']    = 'Ленты RSS';

// Text
$_['text_success']     = 'Ленты RSS были изменены!';
$_['text_list']        = 'Список лент';

// Column
$_['column_name']      = 'Имя RSS ленты';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав на изменение лент!';