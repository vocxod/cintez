<?php
// Heading
$_['heading_title']    = 'Аналитика';

// Text
$_['text_success']     = 'Вы успешно изменили Аналитику!';
$_['text_list']        = 'Список сервисов аналитики';

// Column
$_['column_name']      = 'Название сервиса';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав на изменение Аналитики!';
