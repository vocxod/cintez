<?php
// Heading
$_['heading_title']     = 'Доставка';

// Text
$_['text_success']      = 'Способы Доставки были изменены!';
$_['text_list']         = 'Список Способов доставки';

// Column
$_['column_name']       = 'Способ доставки';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Сортировка';
$_['column_action']     = 'Действие';

// Error
$_['error_permission']  = 'У вас нет прав на изменение Способов доставки!';