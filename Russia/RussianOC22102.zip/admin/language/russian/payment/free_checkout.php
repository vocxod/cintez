<?php
// Heading
$_['heading_title']		 = 'Бесплатно';

// Text
$_['text_payment']		 = 'Оплата';
$_['text_success']		 = 'Настройки модуля оплаты бесплатно обновлены!';
$_['text_edit']          = 'Изменить модуль оплаты Бесплатно';

// Entry
$_['entry_order_status'] = 'Статус заказа после оплаты';
$_['entry_status']		 = 'Статус';
$_['entry_sort_order']	 = 'Сортировка';

// Error
$_['error_permission']	 = 'У вас нет прав для управления модулем оплаты Бесплатно!';