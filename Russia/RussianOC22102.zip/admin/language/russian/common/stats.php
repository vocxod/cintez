<?php
$_['text_complete_status']   = 'Звершенные заказы'; 
$_['text_processing_status'] = 'Заказы в работе'; 
$_['text_other_status']      = 'Другие статусы'; 