<?php
// Text
$_['text_footer'] 	= 'Работает на <a href="http://www.opencart.com" target="_blank">Опенкарт</a>';
$_['text_version'] 	= 'Версия %s';