<?php
// header
$_['heading_title']  = 'Панель управления';

// Text
$_['text_heading']   = 'Панель управления';
$_['text_login']     = 'Введите ваши данные для входа';
$_['text_forgotten'] = 'Забыли пароль ?';

// Entry
$_['entry_username'] = 'Имя пользователя';
$_['entry_password'] = 'Пароль';

// Button
$_['button_login']   = 'Войти';

// Error
$_['error_login']    = 'Неверное имя пользователя или пароль.';
$_['error_token']    = 'Время сессии истекло. Пожалуйста авторизуйтесь заново.';