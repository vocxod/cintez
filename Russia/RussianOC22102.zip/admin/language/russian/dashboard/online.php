<?php
// Heading
$_['heading_title'] = 'Пользователи онлайн';

// Text
$_['text_view']     = 'Подробнее...';