<?php
// Heading
$_['heading_title'] = 'Аналитика продаж';

// Text
$_['text_order']    = 'Заказы';
$_['text_customer'] = 'Клиенты';
$_['text_day']      = 'Сегодня';
$_['text_week']     = 'Неделя';
$_['text_month']    = 'Месяц';
$_['text_year']     = 'Год';