<?php
// Heading
$_['heading_title'] = 'Карта';

$_['text_order']    = 'Заказы';
$_['text_sale']     = 'Продажи';