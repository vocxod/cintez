<?php
// Heading
$_['heading_title']     = 'Последние заказы';

// Column
$_['column_order_id']   = '№ заказа';
$_['column_customer']   = 'Клиент';
$_['column_status']     = 'Статус';
$_['column_total']      = 'Итого';
$_['column_date_added'] = 'Дата заказа';
$_['column_action']     = 'Действие';