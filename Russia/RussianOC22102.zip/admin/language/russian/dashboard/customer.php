<?php
// Heading
$_['heading_title'] = 'Всего клиентов';

// Text
$_['text_view'] = 'Подробнее...';