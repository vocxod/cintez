<?php
// Heading
$_['heading_title']    = 'Фильтр';

// Text
$_['text_module']      = 'Модули';
$_['text_success']     = 'Модуль фильтра успешно изменен!';
$_['text_edit']        = 'Редактирование модуля фильтра';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У вас нет прав для изменения модуля фильтра!';