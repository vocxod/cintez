<?php
// Heading
$_['heading_title']    = 'Профиль';

$_['text_module']      = 'Модули';
$_['text_success']     = 'Модуль аккаунта был изменен!';
$_['text_edit']        = 'Редактировать модуль аккаунта';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У вас нет прав на изменение модуля аккаунта!';