<?php
// Heading
$_['heading_title']    = 'Кнопка PayPal Express Checkout';

// Text
$_['text_module']      = 'Модули';
$_['text_success']     = 'Модуль PayPal Checkout Express успешно изменен!';
$_['text_edit']        = 'Изменить модуль PayPal Express Checkout';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У вас нет прав для изменения данного модуля!';