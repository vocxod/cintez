<?php
// Heading
$_['heading_title']    = 'Информация';

// Text
$_['text_module']      = 'Модули';
$_['text_success']     = 'Модуль информации успешно изменен!';
$_['text_edit']        = 'Редактировать модуль информации';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У вас нет прав для изменения модуля информации!';