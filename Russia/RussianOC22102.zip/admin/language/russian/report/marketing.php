<?php
// Heading
$_['heading_title']    = 'Маркетинговый отчет';

// Text
$_['text_list']         = 'Списки отслеживания';
$_['text_all_status']   = 'Все статусы';

// Column
$_['column_campaign']  = 'Название кампании';
$_['column_code']      = 'Код';
$_['column_clicks']    = 'Клики';
$_['column_orders']    = '№ заказов';
$_['column_total']     = 'Всего';

// Entry
$_['entry_date_start'] = 'Дата начала';
$_['entry_date_end']   = 'Дата окончания';
$_['entry_status']     = 'Статус заказа';