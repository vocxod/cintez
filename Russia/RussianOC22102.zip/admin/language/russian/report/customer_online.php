<?php
// Heading
$_['heading_title']     = 'Отчет о покупателях онлайн';

// Text
$_['text_list']         = 'Список покупателей онлайн';
$_['text_guest']        = 'Гость';

// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Покупатель';
$_['column_url']        = 'Последняя посещенная страница';
$_['column_referer']    = 'Источник перехода';
$_['column_date_added'] = 'Последний клик';
$_['column_action']     = 'Действие';

// Entry
$_['entry_ip']          = 'IP';
$_['entry_customer']    = 'Клиент';