<?php
// Text
$_['text_paid_amazon'] 			= 'Оплата на Amazon';
$_['text_total_shipping'] 		= 'Доставка';
$_['text_total_shipping_tax'] 	= 'Налог на доставку';
$_['text_total_giftwrap'] 		= 'Подарочная упаковка';
$_['text_total_giftwrap_tax'] 	= 'Налог на подарочную упаковку';
$_['text_total_sub'] 			= 'Подитог';
$_['text_tax'] 					= 'Налог';
$_['text_total'] 				= 'Итого';