<?php
// Text
$_['text_total_shipping']		= 'Доставка';
$_['text_total_discount']		= 'Скидка';
$_['text_total_tax']			= 'Налог';
$_['text_total_sub']			= 'Подитог';
$_['text_total']				= 'Итого';