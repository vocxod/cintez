<?php
// Heading
$_['heading_title'] = 'Капча';

// Entry
$_['entry_captcha'] = 'Введите код в поле ниже';

// Error
$_['error_captcha'] = 'Код проверки не совпадает с указанным на картинке!';
