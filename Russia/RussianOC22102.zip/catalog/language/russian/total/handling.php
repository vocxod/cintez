<?php
$_['text_handling'] = 'Оплата за отгрузку';