<?php
$_['text_credit']   = 'Кредит магазина';
$_['text_order_id'] = '№ заказа: %s';