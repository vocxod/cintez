<?php
// Heading
$_['heading_title']    = 'Карта сайта';

// Text
$_['text_special']     = 'Специальные предложения';
$_['text_account']     = 'Мой профиль';
$_['text_edit']        = 'Сведения об учетной записи';
$_['text_password']    = 'Пароль';
$_['text_address']     = 'Адресная книга';
$_['text_history']     = 'История заказов';
$_['text_download']    = 'Загрузки';
$_['text_cart']        = 'Корзина';
$_['text_checkout']    = 'Оформить заказ';
$_['text_search']      = 'Поиск';
$_['text_information'] = 'Информация';
$_['text_contact']     = 'Контакты';