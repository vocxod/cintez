<?php
// Heading
$_['heading_title']    = 'Обслуживание';

// Text
$_['text_maintenance'] = 'Обслуживание';
$_['text_message']     = '<h1 style="text-align:center;">В настоящее время ведутся технические работы. <br/>Пожалуйста, зайдите позже.</h1>';