<?php
// Text
$_['text_title'] = 'Кредитная / Дебитовая карта / Paypal / Бумажник (G2APay)';