<?php
// Heading
$_['heading_title']    = 'Подписка на рассылку';

// Text
$_['text_account']     = 'Профиль';
$_['text_newsletter']  = 'Рассылка';
$_['text_success']     = 'Ваша подписка на рассылку успешно обновлена!';

// Entry
$_['entry_newsletter'] = 'Подписаться';
