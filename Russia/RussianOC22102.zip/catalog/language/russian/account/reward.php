<?php
// Heading
$_['heading_title']      = 'Бонусные баллы';

// Column
$_['column_date_added']  = 'Дата добавления';
$_['column_description'] = 'Описание';
$_['column_points']      = 'Баллы';

// Text
$_['text_account']       = 'Профиль';
$_['text_reward']        = 'Бонусные баллы';
$_['text_total']         = 'Ваше общее количество баллов:';
$_['text_empty']         = 'У Вас нет бонусов!';