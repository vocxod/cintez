<?php
// Heading
$_['heading_title'] = 'Выйти';

// Text
$_['text_message']  = '<p>Вы вышли с Партнерской учетной записи.</p>';
$_['text_account']  = 'Профиль';
$_['text_logout']   = 'Выйти';