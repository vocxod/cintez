<?php
// Heading
$_['heading_title']        = 'Партнёрский профиль';

// Text
$_['text_account']         = 'Профиль';
$_['text_my_account']      = 'Партнерский профиль';
$_['text_my_tracking']     = 'Информация для отслеживания';
$_['text_my_transactions'] = 'Транзакции';
$_['text_edit']            = 'Редактировать профиль';
$_['text_password']        = 'Изменить пароль';
$_['text_payment']         = 'Изменить настройки платежей';
$_['text_tracking']        = 'Пользовательский Партнерский код для отслеживания';
$_['text_transaction']     = 'История транзакций';