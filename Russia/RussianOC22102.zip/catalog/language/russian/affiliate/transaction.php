<?php
// Heading
$_['heading_title']      = 'Ваши транзакции';

// Column
$_['column_date_added']  = 'Дата добавления';
$_['column_description'] = 'Описание';
$_['column_amount']      = 'Сумма (%s)';

// Text
$_['text_account']       = 'Профиль';
$_['text_transaction']   = 'Ваши транзакции';
$_['text_balance']       = 'Ваш текущий баланс составляет:';
$_['text_empty']         = 'Вы не имеете каких-либо сделок!';