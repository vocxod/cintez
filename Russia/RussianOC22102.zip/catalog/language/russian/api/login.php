<?php
// Text
$_['text_success'] = 'API сессия успешно запущена!';

// Error
$_['error_key']  = 'Неверный ключ API!';
$_['error_ip']   = 'Вашему IP %s запрещен доступ к этому API!';