<?php
// Text
$_['text_success']     = 'Валюты успешно изменены!';

// Error
$_['error_permission'] = 'У вас нет прав ни изменение валют!';
$_['error_currency']   = 'Неверный код валюты!';