<?php
// Heading
$_['heading_title']    = 'Партнерская программа';

// Text
$_['text_register']    = 'Регистрация';
$_['text_login']       = 'Войти';
$_['text_logout']      = 'Выход';
$_['text_forgotten']   = 'Забыли пароль';
$_['text_account']     = 'Моя учетная запись';
$_['text_edit']        = 'Редактировать профиль';
$_['text_password']    = 'Пароль';
$_['text_payment']     = 'Варианты оплаты';
$_['text_tracking']    = 'Отслеживание партнеров';
$_['text_transaction'] = 'Транзакции';
