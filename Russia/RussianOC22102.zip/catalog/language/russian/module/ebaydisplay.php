<?php
$_['heading_title']     = 'В магазин на eBay';