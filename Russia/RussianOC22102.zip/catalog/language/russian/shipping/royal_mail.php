<?php
// Text
$_['text_title']                 = 'Royal Mail';
$_['text_weight']                = 'Вес:';
$_['text_insurance']             = 'Страховать на сумму:';
$_['text_1st_class_standard']    = 'Стандартная почта первого класса';
$_['text_1st_class_recorded']    = 'Заказная почта первого класса';
$_['text_2nd_class_standard']    = 'Стандартная почта второго класса';
$_['text_2nd_class_recorded']    = 'Заказная почта второго класса';
$_['text_special_delivery_500']  = 'Срочная доставка на следующий день (£500)';
$_['text_special_delivery_1000'] = 'Срочная доставка на следующий день (£1000)';
$_['text_special_delivery_2500'] = 'Срочная доставка на следующий день (£2500)';
$_['text_standard_parcels']      = 'Стандартные посылки';
$_['text_airmail']               = 'Авиапочта';
$_['text_international_signed']  = 'Международная с подписью';
$_['text_airsure']               = 'Airsure';
$_['text_surface']               = 'Наземным транспортом';