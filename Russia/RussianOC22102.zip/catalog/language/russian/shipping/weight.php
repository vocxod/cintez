<?php
// Text
$_['text_title']  = 'Оплата доставки по весу';
$_['text_weight'] = 'Вес:';