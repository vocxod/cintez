<?php
// Text
$_['text_title']  = 'United States Postal Service';
$_['text_weight'] = 'Вес:';
$_['text_eta']    = 'Приблизительное время:';