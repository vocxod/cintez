<?php
// Text
$_['text_title']    = 'Почта Австралии';
$_['text_express']  = 'Экспресс';
$_['text_standard'] = 'Стандарт';
$_['text_eta']      = 'суток';