<?php
// Text
$_['text_subject']	= '%s - Отзыв о товаре';
$_['text_waiting']	= 'У вас появился новый отзыв о товаре.';
$_['text_product']	= 'Товар: %s';
$_['text_reviewer']	= 'Посетитель: %s';
$_['text_rating']	= 'Рейтинг: %s';
$_['text_review']	= 'Текст обзора:';